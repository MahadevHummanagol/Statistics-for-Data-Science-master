# Statistics and Probability for Data Science

![image](https://wpforms.com/wp-content/uploads/2019/02/online-business-statistics.jpg)

Learning Statistics is one of the most Important step to get into the World of Data Science and Machine Learning. Statistics helps us to know data in a much better way and explains the behavior of the data based upon certain factors. It has many Elements which help us to understand the data better that includes Probability, Distributions, Descriptive Analysis, Inferential Analysis, Comparative Analysis, Chi-Square Test, T Test, Z test, AB Testing etc.

## Contents

* 1. Basic Probability
* 2. Binomial Distribution
* 3. Discrete Probability Distributions
* 4. Descriptive Statistics
* 5. Inferential Statistics
* 6. Comparative Statistcs
* 7. AB Testing

Reach me out, If any Query or Doubts
Contact me on Linkedin
